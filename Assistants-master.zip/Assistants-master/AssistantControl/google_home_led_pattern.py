#!/usr/bin/env python

def GoogleHomeLedPattern(show):
    basis = [0] * 3 * 3
    basis[0] = 1
    basis[4] = 1
    basis[8] = 2
    
    return basis
    