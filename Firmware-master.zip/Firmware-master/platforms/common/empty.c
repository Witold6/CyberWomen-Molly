/*
 * This is an empty C source file, used when building default firmware configurations.
 */
