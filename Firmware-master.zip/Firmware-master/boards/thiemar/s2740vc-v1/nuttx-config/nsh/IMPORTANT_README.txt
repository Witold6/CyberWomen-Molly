N.B. The nsh build is not complete - it will build but is not pinied out to the HW DO NOT ATTEMPT TO RUN IT!
